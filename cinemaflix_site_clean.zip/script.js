window.addEventListener("DOMContentLoaded", () => {
  console.log("CinemaFlix loaded successfully!");
  alert("Welcome to CinemaFlix 🎬");
});

function performSearch() {
  const query = document.getElementById("searchInput").value.trim().toLowerCase();
  
  if (query === "") {
    alert("Please enter a title to search.");
    return;
  }

  const mockDatabase = [
    "the fox and the dragon",
    "space voyagers",
    "rainstorm chase",
    "dragon puppeteer: the movie",
    "prime nights",
    "campfire tales",
    "bushcraft for kids",
    "therian legends"
  ];

  const results = mockDatabase.filter(title => title.toLowerCase().includes(query));

  if (results.length > 0) {
    alert(`Search Results:\n- ${results.join('\n- ')}`);
  } else {
    alert("No results found for \"" + query + "\".");
  }
}

function toggleTheme() {
  document.body.classList.toggle("light-mode");
}
